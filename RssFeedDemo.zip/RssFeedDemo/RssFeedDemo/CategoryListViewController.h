//
//  CategoryListViewController.h
//  RssFeedDemo
//
//  Created by Pravin Gawale on 28/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoryListViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

