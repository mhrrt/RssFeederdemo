//
//  CategoryTableViewCell.h
//  RssFeedDemo
//
//  Created by Pravin Gawale on 30/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoryTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *articleImage;
@property (weak, nonatomic) IBOutlet UILabel *articleTitle;

@end
