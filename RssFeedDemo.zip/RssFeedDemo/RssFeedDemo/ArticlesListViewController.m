//
//  ArticlesListViewController.m
//  RssFeedDemo
//
//  Created by Pravin Gawale on 30/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import "ArticlesListViewController.h"
#import "CategoryTableViewCell.h"
#import "RssFeedDataManager.h"
#import "NewsItem.h"
#import "ArticleViewController.h"

@interface ArticlesListViewController ()

@property (nonatomic,retain) NSArray *newsItems;
@property (nonatomic,retain) NewsItem *selectedArticle;

@end

@implementation ArticlesListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.title = self.categoryName;

    [self getAllArticlesForCategory:self.categoryName];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)getAllArticlesForCategory:(NSString *) categoryName {
    [self startLoader];
    
    __weak ArticlesListViewController *weakself = self;
    
    [[RssFeedDataManager sharedManager] fetchAllNewsArticlesToCategory:self.categoryName completion:^(NSArray *responseData, NSError *error) {
        [weakself stopLoader];
        //Get all articles
        _newsItems = responseData;
        //Load table
        [weakself loadTable];
        
    }];
}

-(void)loadTable {
    //On main thred with async
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

-(void)startLoader {
    //On main thred with async
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.activityIndicator startAnimating];
    });
}

-(void)stopLoader {
    //On main thred with async
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.activityIndicator stopAnimating];
    });
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showArticle"]) {
        ArticleViewController *vc = [segue destinationViewController];
        [vc setArticle:_selectedArticle];//Pass on selected article
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark- UITableview Data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _newsItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *simpleTableIdentifier = @"CategoryTableViewCell";
    
    CategoryTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil) {
        cell = [[CategoryTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    NewsItem * article = [_newsItems objectAtIndex:indexPath.row];
    cell.articleTitle.text =  article.title;
    cell.articleImage.image = [UIImage imageNamed:@"placeHolderIcon.png"];
    
    if (article.imageUrl.length && article.imageUrl) {
        
        dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_HIGH, 0ul);
        dispatch_async(queue, ^(void) {
            //  You may want to cache this explicitly instead of reloading every time.
            NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:article.imageUrl]];
            UIImage* image = [[UIImage alloc] initWithData:imageData];
            dispatch_async(dispatch_get_main_queue(), ^{
                // Capture the indexPath variable, not the cell variable, and use that
                CategoryTableViewCell *blockCell = [tableView cellForRowAtIndexPath:indexPath];
                cell.articleImage.image = image;
                [blockCell setNeedsLayout];
            });
        });
    }
    return cell;
}

#pragma mark- UITableview Delegate

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NewsItem * article = [_newsItems objectAtIndex:indexPath.row];
    _selectedArticle = article;
    
    return indexPath;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
 
}

@end
