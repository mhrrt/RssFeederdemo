//
//  NewsItem.m
//  RssFeedDemo
//
//  Created by Pravin Gawale on 28/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import "NewsItem.h"

@implementation NewsItem

@dynamic title;
@dynamic descriptionText;
@dynamic link;
@dynamic category;
@dynamic pubDate;
@dynamic imageUrl;

@end
