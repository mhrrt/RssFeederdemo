//
//  ArticlesListViewController.h
//  RssFeedDemo
//
//  Created by Pravin Gawale on 30/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ArticlesListViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic, copy) NSString* categoryName;

@end
