//
//  RssFeedDataManager.h
//  RssFeedDemo
//
//  Created by Pravin Gawale on 29/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "FeedRequester.h"

@interface RssFeedDataManager : NSObject

@property (readonly, strong, nonatomic) NSManagedObjectContext *mainManagedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectContext *backgroundManagedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

+ (RssFeedDataManager *)sharedManager;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

//Get all news items
- (void)getAllNewsItems:(FetchItemsRequestCompletionHandler)completionHandler;

- (void)getAllCategoriesOfNewsItems:(FetchItemsRequestCompletionHandler)completionHandler;

- (void)fetchAllNewsArticlesToCategory:(NSString *) categoryString completion:(FetchItemsRequestCompletionHandler)completionHandler;

- (void)purgeAllData;
@end
