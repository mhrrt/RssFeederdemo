//
//  FeedRequestParser.m
//  RssFeedDemo
//
//  Created by Pravin Gawale on 28/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import "FeedRequestParser.h"

@interface FeedRequestParser ()

@property(nonatomic) NSString *element;
@property(nonatomic,strong) NSDictionary *attributeDict;

@property(nonatomic,strong) NSMutableArray *allitems;

@property(nonatomic,strong) NSMutableDictionary *item;

@property(nonatomic) NSMutableString *title;
@property(nonatomic) NSMutableString *descriptionText;
@property(nonatomic) NSMutableString *link;
@property(nonatomic) NSMutableString *category;
@property(nonatomic) NSMutableString *pubDateString;
@property(nonatomic) NSMutableString *imageURL;
@property(assign) FetchItemsRequestCompletionHandler completionHandler;

@end
@implementation FeedRequestParser

- (void)parserFeed:(NSData *) responseData completion:(FetchItemsRequestCompletionHandler)completionHandler {
   
    _allitems   = [[NSMutableArray alloc] init];
    _completionHandler = completionHandler;
    
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:responseData];
    [parser setDelegate:self];
    [parser parse];//Parse xml
    

}

//Removes white spaces and new lines
- (NSString *)removeNewLineAndExtraWhiteSpace:(NSString *) stringValue {

    return [stringValue stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

#pragma mark - NSXMLDelegate Methods

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    
    _element = elementName;
    _attributeDict = attributeDict;

    if ([_element isEqualToString:NEWS_ENTITY_ITEM_KEY]) {

        _item    = [[NSMutableDictionary alloc] init];
        _title = [[NSMutableString alloc] init];
        _descriptionText = [[NSMutableString alloc] init];
        _link   = [[NSMutableString alloc] init];
        _category   = [[NSMutableString alloc] init];
        _pubDateString   = [[NSMutableString alloc] init];
        _imageURL   = [[NSMutableString alloc] init];
        
    }
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
    
    if ([_element isEqualToString:NEWS_ENTITY_TITLE_KEY] && _item) {
        [_title appendString:[self removeNewLineAndExtraWhiteSpace:string]];
    } else if ([_element isEqualToString:NEWS_ENTITY_DSCR_KEY] && _item) {
        [_descriptionText appendString:[self removeNewLineAndExtraWhiteSpace:string]];
    } else if ([_element isEqualToString:NEWS_ENTITY_LINK_KEY] && _item) {
        [_link appendString:[self removeNewLineAndExtraWhiteSpace:string]];
    } else if ([_element isEqualToString:NEWS_ENTITY_CAT_KEY] && _item) {
        [_category appendString:[self removeNewLineAndExtraWhiteSpace:string]];
    } else if ([_element isEqualToString:NEWS_ENTITY_PDATE_KEY] && _item) {
        [_pubDateString appendString:[self removeNewLineAndExtraWhiteSpace:string]];
    } else if ([_element isEqualToString:NEWS_ENTITY_MEDIA_THUMBNAIL_KEY] && _item) {
        [_imageURL appendString:[_attributeDict valueForKey:NEWS_ENTITY_URL_KEY]];
    }
    
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    if ([elementName isEqualToString:NEWS_ENTITY_ITEM_KEY] && _item) {
        
       [_item setObject:_title forKey:NEWS_ENTITY_TITLE_KEY];
       [_item setObject:_descriptionText forKey:NEWS_ENTITY_DSCR_KEY];
       [_item setObject:_link forKey:NEWS_ENTITY_LINK_KEY];
       [_item setObject:_category forKey:NEWS_ENTITY_CAT_KEY];
       [_item setObject:_pubDateString forKey:NEWS_ENTITY_PDATE_KEY];
       [_item setObject:_imageURL forKey:NEWS_ENTITY_IMAGEURL_KEY];
        
       [_allitems addObject:[_item copy]];
        _item = nil;
    }
}

- (void)parserDidEndDocument:(NSXMLParser *)parser {
    _completionHandler(_allitems,nil);
}
@end
