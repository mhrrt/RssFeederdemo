//
//  ArticleViewController.m
//  RssFeedDemo
//
//  Created by Pravin Gawale on 30/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import "ArticleViewController.h"

@interface ArticleViewController ()

@end

@implementation ArticleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = self.article.title;
    
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.article.link]]];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)startLoader {
    //On main thred with async
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.activityIndicator startAnimating];
    });
}

-(void)stopLoader {
    //On main thred with async
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.activityIndicator stopAnimating];
    });
}

#pragma mark- UIWebview Delegate

- (void)webViewDidStartLoad:(UIWebView *)webView {
    [self startLoader];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    [self stopLoader];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    [self stopLoader];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
