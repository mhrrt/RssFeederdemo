//
//  FeedRequester.h
//  RssFeedDemo
//
//  Created by Pravin Gawale on 28/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FeedRequester : NSObject

typedef void (^FetchItemsRequestCompletionHandler)(NSArray *responseData, NSError *error);

- (void)fetchNewsItemsDataWithCompletionHandler:(FetchItemsRequestCompletionHandler)completionHandler;

@end
