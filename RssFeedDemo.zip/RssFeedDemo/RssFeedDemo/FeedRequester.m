//
//  FeedRequester.m
//  RssFeedDemo
//
//  Created by Pravin Gawale on 28/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import "FeedRequester.h"
#import "FeedRequestParser.h"

@interface FeedRequester ()

@property(nonatomic,strong) NSURLSessionDataTask* dataTask;

@end

@implementation FeedRequester


- (void)fetchNewsItemsDataWithCompletionHandler:(FetchItemsRequestCompletionHandler)completionHandler {
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    
    NSURL *rssFeed = [NSURL URLWithString:RSS_FEED_URL];
        
    self.dataTask = [session dataTaskWithURL:rssFeed completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
        
        if (!error) {
            
            FeedRequestParser *parse = [[FeedRequestParser alloc] init];
            [parse parserFeed:data completion:completionHandler];
                        
        }else {
            NSLog(@"Error - %@",error.localizedDescription);
        }
        
    }] ;
    [self.dataTask resume];
}

- (void)cancelRequest {
    
    [self.dataTask cancel];
    self.dataTask = nil;
}

@end
