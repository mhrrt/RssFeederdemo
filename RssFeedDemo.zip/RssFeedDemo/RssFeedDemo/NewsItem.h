//
//  NewsItem.h
//  RssFeedDemo
//
//  Created by Pravin Gawale on 28/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import <CoreData/CoreData.h>

@interface NewsItem : NSManagedObject

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *descriptionText;
@property (nonatomic, strong) NSString *link;
@property (nonatomic, strong) NSString *category;
@property (nonatomic, strong) NSString *pubDate;
@property (nonatomic, strong) NSString *imageUrl;

@end
