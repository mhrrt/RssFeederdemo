//
//  RssFeedDataManager.m
//  RssFeedDemo
//
//  Created by Pravin Gawale on 29/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import "RssFeedDataManager.h"
#import "NewsItem.h"

@interface RssFeedDataManager()
@property (nonatomic,retain) NSArray *newsItems;

@end

@implementation RssFeedDataManager

#pragma mark - Core Data stack

@synthesize mainManagedObjectContext = _mainManagedObjectContext;
@synthesize backgroundManagedObjectContext = _backgroundContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;

+ (RssFeedDataManager *)sharedManager {
    static dispatch_once_t pred;
    static RssFeedDataManager *manager = nil;
    dispatch_once(&pred, ^{ manager = [[self alloc] init]; });
    return manager;
}

//Get all news items
- (void)getAllNewsItems:(FetchItemsRequestCompletionHandler)completionHandler {
   //Check if cached
    NSArray *fetchedItems = [self getCachedDataForFeed];
    
    if (fetchedItems && fetchedItems.count) {
        completionHandler(fetchedItems,nil);
    }
    //Get news items from server
    [self fetchNewsItemsFromServer:completionHandler];
    
}

//Delete all data
- (void)purgeAllData {
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] initWithEntityName:NEWS_ENTITY];
    [fetchRequest setIncludesPropertyValues:NO];

    [[self backgroundManagedObjectContext] performBlockAndWait:^{
        
        __block NSError *error = nil;
        NSArray *fetchedObjects = [[self backgroundManagedObjectContext] executeFetchRequest:fetchRequest error:&error];
        for (NSManagedObject *object in fetchedObjects)
        {
            [[self backgroundManagedObjectContext] deleteObject:object];
        }
        if (![[self backgroundManagedObjectContext] save:&error]) {
            return;
        } else {
            
            [[self backgroundManagedObjectContext].parentContext performBlock:^{
                [[self backgroundManagedObjectContext].parentContext save:&error];
            }];
        }
    }];
}

- (void)getAllCategoriesOfNewsItems:(FetchItemsRequestCompletionHandler)completionHandler  {
    
    __weak RssFeedDataManager *weakSelf = self;
    
    [self getAllNewsItems:^(NSArray *responseData, NSError *error) {
        if (!error) {
            [weakSelf fetchAllCategories:completionHandler];
        }
    }];
    
}

- (void)fetchAllCategories:(FetchItemsRequestCompletionHandler)completionHandler  {
   
    NSError *error;

    NSEntityDescription *entity = [NSEntityDescription  entityForName:NEWS_ENTITY inManagedObjectContext:[self backgroundManagedObjectContext]];
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    [request setEntity:entity];
    [request setResultType:NSDictionaryResultType];
    [request setReturnsDistinctResults:YES];
    [request setPropertiesToFetch:@[NEWS_ENTITY_CAT_KEY]];
    

    NSArray *fetchReturn=[[self backgroundManagedObjectContext] executeFetchRequest:request error:&error];
    NSLog(@"fetchReturn=%@",fetchReturn);
    
    if (fetchReturn.count) {
        completionHandler (fetchReturn ,nil);
    }

}

- (void)fetchAllNewsArticlesToCategory:(NSString *) categoryString completion:(FetchItemsRequestCompletionHandler)completionHandler {
    
    NSError *error;
    
    NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];

    NSEntityDescription *entity = [NSEntityDescription  entityForName:NEWS_ENTITY inManagedObjectContext:[self backgroundManagedObjectContext]];
    [fetchRequest setEntity:entity];

    [fetchRequest setPredicate:[NSPredicate predicateWithFormat:@"SELF.category == %@",categoryString]];
    
    NSArray *fetchReturn=[[self backgroundManagedObjectContext] executeFetchRequest:fetchRequest error:&error];
    NSLog(@"fetchReturn=%@",fetchReturn);
    
    if (fetchReturn.count) {
        completionHandler (fetchReturn ,nil);
    }
    
}

- (void)fetchNewsItemsFromServer:(FetchItemsRequestCompletionHandler)completionHandler {
    
    FeedRequester *requester = [[FeedRequester alloc]init];
    
    [requester fetchNewsItemsDataWithCompletionHandler:^(NSArray *responseData, NSError *error) {
        if (!error) {
            _newsItems = responseData;
            NSError *anyError = nil;
            [self saveAllDataInCoreDataError:&anyError];
            if (anyError) {
                NSLog(@"error cored data -=%@",error.localizedDescription);
            } else {
                completionHandler(_newsItems,nil);
            }
        }
    }];
    
}

- (NSArray *)getCachedDataForFeed {
    
    NSArray *fetchedNewsItems = nil;
    
    NSFetchRequest *request = [NSFetchRequest fetchRequestWithEntityName:NEWS_ENTITY];
    
    NSError *anyError = nil;
    
    fetchedNewsItems = [self.mainManagedObjectContext executeFetchRequest:request error:&anyError];
    
    if (!fetchedNewsItems) {
        NSLog(@"error cored data -=%@",anyError.localizedDescription);
       
    } else {
        NSLog(@"fetched News From Core data %@",fetchedNewsItems);
    }
    
    return fetchedNewsItems;
}

- (void)saveAllDataInCoreDataError:(NSError * __autoreleasing *)error{
    
    //Writing Context
    
    [[self backgroundManagedObjectContext] performBlockAndWait:^{
        //lengthy background operation
        for (NSDictionary *dict in _newsItems) {
            
            NewsItem *newsItem = [NSEntityDescription insertNewObjectForEntityForName:NEWS_ENTITY inManagedObjectContext:[self backgroundManagedObjectContext]];
            
            newsItem.title = [dict valueForKey:NEWS_ENTITY_TITLE_KEY];
            newsItem.descriptionText = [dict valueForKey:NEWS_ENTITY_DSCR_KEY];
            newsItem.link = [dict valueForKey:NEWS_ENTITY_LINK_KEY];
            newsItem.category = [dict valueForKey:NEWS_ENTITY_CAT_KEY];
            newsItem.pubDate = [dict valueForKey:NEWS_ENTITY_PDATE_KEY];
            newsItem.imageUrl = [dict valueForKey:NEWS_ENTITY_IMAGEURL_KEY];
            
        }
        
        
        if (![[self backgroundManagedObjectContext] save:error]) {
            return;
        } else {
            
            [[self backgroundManagedObjectContext].parentContext performBlock:^{
                [[self backgroundManagedObjectContext].parentContext save:error];
            }];
        }
    }];
    
}

- (NSURL *)applicationDocumentsDirectory {
    // The directory the application uses to store the Core Data store file. This code uses a directory named "newapp.RssFeedDemo" in the application's documents directory.
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

- (NSManagedObjectModel *)managedObjectModel {
    // The managed object model for the application. It is a fatal error for the application not to be able to find and load its model.
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"RssFeedDemo" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

- (NSPersistentStoreCoordinator *)persistentStoreCoordinator {
    // The persistent store coordinator for the application. This implementation creates and returns a coordinator, having added the store for the application to it.
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    
    // Create the coordinator and store
    
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"RssFeedDemo.sqlite"];
    NSError *error = nil;
    NSString *failureReason = @"There was an error creating or loading the application's saved data.";
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        // Report any error we got.
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        dict[NSLocalizedDescriptionKey] = @"Failed to initialize the application's saved data";
        dict[NSLocalizedFailureReasonErrorKey] = failureReason;
        dict[NSUnderlyingErrorKey] = error;
        error = [NSError errorWithDomain:@"YOUR_ERROR_DOMAIN" code:9999 userInfo:dict];
        // Replace this with code to handle the error appropriately.
        // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _persistentStoreCoordinator;
}


- (NSManagedObjectContext *)mainManagedObjectContext {
    // Returns the managed object context for the application (which is already bound to the persistent store coordinator for the application.)
    if (_mainManagedObjectContext != nil) {
        return _mainManagedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (!coordinator) {
        return nil;
    }
    _mainManagedObjectContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSMainQueueConcurrencyType];
    _mainManagedObjectContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy;
    [_mainManagedObjectContext setPersistentStoreCoordinator:coordinator];
    return _mainManagedObjectContext;
}

- (NSManagedObjectContext *)backgroundManagedObjectContext {
    // Returns the managed object context for the application (which is already bound to the persistent store coordinator for the application.)
    if (_backgroundContext != nil) {
        return _backgroundContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (!coordinator) {
        return nil;
    }
    _backgroundContext = [[NSManagedObjectContext alloc] initWithConcurrencyType:NSPrivateQueueConcurrencyType];
    _backgroundContext.mergePolicy = NSMergeByPropertyObjectTrumpMergePolicy;
    _backgroundContext.parentContext = self.mainManagedObjectContext;
    return _backgroundContext;
}

#pragma mark - Core Data Saving support

- (void)saveContext {
    NSManagedObjectContext *managedObjectContext = self.mainManagedObjectContext;
    if (managedObjectContext != nil) {
        NSError *error = nil;
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        }
    }
}

@end
