//
//  ArticleViewController.h
//  RssFeedDemo
//
//  Created by Pravin Gawale on 30/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NewsItem.h"

@interface ArticleViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIWebView *webView;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@property (nonatomic,retain) NewsItem *article;

@end
