//
//  CategoryListViewController.m
//  RssFeedDemo
//
//  Created by Pravin Gawale on 28/07/16.
//  Copyright © 2016 Pravin Gawale. All rights reserved.
//

#import "CategoryListViewController.h"
#import "RssFeedDataManager.h"
#import "ArticlesListViewController.h"

@interface CategoryListViewController ()

@property (nonatomic,retain) NSArray *newsItems;
@property (nonatomic,copy) NSString *selectedCategory;

@end

@implementation CategoryListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.navigationController.navigationBar.barTintColor = [UIColor grayColor];
    self.title = @"Todays News";

    UIRefreshControl *refreshControl = [[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
    [self.tableView addSubview:refreshControl];
    
    [self refreshNewsItems];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)refresh:(UIRefreshControl *)refreshControl {
    [[RssFeedDataManager sharedManager] purgeAllData];
    [self refreshNewsItems];
    
    [refreshControl endRefreshing];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)refreshNewsItems {
    [self startLoader];

    __weak CategoryListViewController *weakself = self;
    
    [[RssFeedDataManager sharedManager] getAllCategoriesOfNewsItems:^(NSArray *responseData, NSError *error) {
        
        [weakself stopLoader];
        _newsItems = responseData;
        //Refresh Table with new data
        [weakself loadTable];

    }];
    
}

-(void)loadTable {
    //On main thred with async
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.tableView reloadData];
    });
}

-(void)startLoader {
    //On main thred with async
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.activityIndicator startAnimating];
    });
}

-(void)stopLoader {
    //On main thred with async
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.activityIndicator stopAnimating];
    });
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([[segue identifier] isEqualToString:@"showArticleList"]) {
        ArticlesListViewController *vc = [segue destinationViewController];
        [vc setCategoryName:_selectedCategory];//Pass selected category name
    }
}

#pragma mark- UITableview Data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return _newsItems.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *simpleTableIdentifier = @"CategoryListTableViewCell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:simpleTableIdentifier];
    }
    
    cell.textLabel.text = [[_newsItems objectAtIndex:indexPath.row] valueForKey:NEWS_ENTITY_CAT_KEY];
    return cell;
}

#pragma mark- UITableview Delegate

- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString* cat = [[_newsItems objectAtIndex:indexPath.row] valueForKey:NEWS_ENTITY_CAT_KEY];
    _selectedCategory = cat;//Get selected category name
    
    return indexPath;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    //Select on category list
}

@end
